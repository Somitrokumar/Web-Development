const inputValue = document.getElementById("user-input");

document.querySelectorAll(".operations").forEach(function (item) {
  item.addEventListener("click", function (e) {
    let lastValue = inputValue.innerText.slice(-1);
    let buttonValue = e.target.innerText;

    if (!isNaN(lastValue) && buttonValue === "=") {
      inputValue.innerText = eval(inputValue.innerText);
    } else if (buttonValue === "AC") {
      inputValue.innerText = "0";
    } else if (buttonValue === "DEL") {
      inputValue.innerText = inputValue.innerText.slice(0, -1);
      if (inputValue.innerText.length === 0) {
        inputValue.innerText = "0";
      }
    } else if (buttonValue === "%") {
      if (!isNaN(lastValue)) {
        inputValue.innerText = (parseFloat(inputValue.innerText) / 100).toString();
      }
    } else {
      if (!isNaN(lastValue) || lastValue === ".") {
        inputValue.innerText += buttonValue;
      }
    }
  });
});

document.querySelectorAll(".numbers").forEach(function (item) {
  item.addEventListener("click", function (e) {
    if (inputValue.innerText === "0") {
      inputValue.innerText = "";
    }
    inputValue.innerText += e.target.innerText.trim();
  });
});